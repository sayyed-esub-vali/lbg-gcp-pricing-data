export default {
  preset: 'ts-jest',
  testEnvironment: 'node',
  testMatch: ['**/src/__tests__/**/*.test.ts', '**/?(*.)+(spec|test).ts'],
  coveragePathIgnorePatterns: ['/node_modules/', '/src/config/', '/src/models/', '/dist/', '/coverage/'],
  collectCoverage: true,
  coverageDirectory: 'coverage',
  collectCoverageFrom: ['src/**/*.ts', '!src/server.ts',  '!src/swaggerConfig.ts'],
  setupFilesAfterEnv: ['<rootDir>/src/__tests__/setup.ts'],
  coverageReporters: ['json', 'lcov', 'text', 'clover'],
  moduleFileExtensions: ['js',  'ts' ],
  transform: {
   
  },
  extensionsToTreatAsEsm: ['.ts'],
  moduleNameMapper: {"^(\\.{1,2}/.*)\\.js$": "$1"},
};