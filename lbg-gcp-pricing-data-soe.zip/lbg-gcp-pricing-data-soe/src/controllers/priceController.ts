import express from "express";

import { Storage } from "@google-cloud/storage";
import { BigQuery } from "@google-cloud/bigquery";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import fs from "fs";

import dotenv from "dotenv";

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

dotenv.config();
import { Request, Response } from "express-serve-static-core";
import pkg from "pg";
const { Pool } = pkg;

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: Number(process.env.DB_PORT),
});

export const getPrices = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await pool.query(
      'SELECT * FROM "pricingschema"."loan_details"'
    );

    res.status(200).json(result);
  } catch (error) {
    console.error("Error querying BigQuery:", error);
    res.status(500).send("Internal Server Error");
  }
};

export const getByEmail = async (req: Request, res: Response) => {
  const emailId = req.query.email_id;
  if (!emailId) {
    return res.status(400).send("email_id query parameter is required");
  }

  try {
    const result = await pool.query(
      'SELECT * FROM "pricingschema"."loan_details" WHERE "email_id" = $1',
      [emailId]
    );
    if (result.rows.length === 0) {
      return res.status(404).send("No records found with the given email_id");
    }
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
};
