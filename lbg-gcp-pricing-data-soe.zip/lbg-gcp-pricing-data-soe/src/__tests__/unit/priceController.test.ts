import request from "supertest";
import app from "../../app.js";
import { Pool } from "pg";

jest.mock("pg", () => {
  const mPool = {
    query: jest.fn(),
    connect: jest.fn(),
    end: jest.fn(),
  };
  return { Pool: jest.fn(() => mPool) };
});

describe("Price Controller", () => {
  let pool: any;
  let server: any;

  beforeAll((done) => {
    pool = new Pool();
    const port = 9000;
    server = app.listen(port, () => {
      console.log(`Test server is running on http://localhost:${port}`);
      done();
    });
  });

  afterAll((done) => {
    server.close(done);
  });

  it("should return 200 and a list of all-loan-details on GET /api/all-loan-details", async () => {
    const mockPrices = [
      {
        portfolio_id: 2,
        govt_scheme: "Scheme B",
        currency_code_facility: "EUR",
        product_type_loan: "Type 2",
        effective_date_loan: "2025-01-01T18:30:00.000Z",
        type_facility: "Facility 2",
        interest_rate_loan: "3.60",
        rate_maturity_loan: "4.10",
        email_id: "user2@example.com",
      },
      {
        portfolio_id: 2,
        govt_scheme: "Scheme B",
        currency_code_facility: "EUR",
        product_type_loan: "Type 2",
        effective_date_loan: "2025-01-01T18:30:00.000Z",
        type_facility: "Facility 2",
        interest_rate_loan: "3.60",
        rate_maturity_loan: "4.10",
        email_id: "user2@example.com",
      },
    ];
    (pool.query as jest.Mock).mockResolvedValue({ rows: mockPrices });

    const response = await request(app).get("/api/all-loan-details");
    expect(response.status).toBe(200);
    expect(response.body.rows).toEqual(mockPrices);
  });

  it("should return 500 on error", async () => {
    jest.spyOn(console, "error").mockImplementation(() => {});
    pool.query.mockRejectedValue(new Error("Database error"));

    const response = await request(app).get("/api/all-loan-details");
    expect(response.status).toBe(500);
    expect(response.text).toBe("Internal Server Error");
  });

  it("should return 400 if email_id is not provided on GET /api/loan-details-by-email", async () => {
    const response = await request(app).get("/api/loan-details-by-email");
    expect(response.status).toBe(400);
    expect(response.text).toBe("email_id query parameter is required");
  });

  it("should return 404 if no records found with the given email_id", async () => {
    pool.query.mockResolvedValue({ rows: [] });

    const response = await request(app).get(
      "/api/loan-details-by-email?email_id=test@example.com"
    );
    expect(response.status).toBe(404);
    expect(response.text).toBe("No records found with the given email_id");
  });

  it("should return 200 and the records if email_id is provided on GET /api/loan-details-by-email", async () => {
    const mockRecords = [{ id: 1, email_id: "test@example.com", price: 100 }];
    pool.query.mockResolvedValue({ rows: mockRecords });

    const response = await request(app).get(
      "/api/loan-details-by-email?email_id=test@example.com"
    );
    expect(response.status).toBe(200);
    expect(response.body).toEqual(mockRecords);
  });

  it("should return 500 on server error for GET /api/loan-details-by-email", async () => {
    jest.spyOn(console, "error").mockImplementation(() => {});
    pool.query.mockRejectedValue(new Error("Database error"));

    const response = await request(app).get(
      "/api/loan-details-by-email?email_id=test@example.com"
    );
    expect(response.status).toBe(500);
    expect(response.text).toBe("Server error");
  });
});
