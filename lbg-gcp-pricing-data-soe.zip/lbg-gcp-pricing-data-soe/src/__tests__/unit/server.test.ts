import request from "supertest";
import app from "../../app.js";

describe("Server", () => {
  let server: any;

  beforeAll((done) => {
    const port = 8000;
    server = app.listen(port, () => {
      console.log(`Test server is running on http://localhost:${port}`);
      done();
    });
  });

  afterAll((done) => {
    server.close(done);
  });

  it("should start the server on specified port", async () => {
    const response = await request(app).get("/");
    expect(response.status).toBe(200);
  });

  it("should log the correct message when the server starts", () => {
    const consoleSpy = jest.spyOn(console, "log");
    const port = 3000;
    const mockServer = {
      listen: (port: number, callback: () => void) => {
        callback();
      },
    };
    jest
      .spyOn(app, "listen")
      .mockImplementation((port: number, listeningListener?: Function) => {
        if (listeningListener) (listeningListener as () => void)();
        return server;
      });
    app.listen(port, () => {
      console.log(`Server is running on http://localhost:${port}`);
    });
    expect(consoleSpy).toHaveBeenCalledWith(
      `Server is running on http://localhost:${port}`
    );
    consoleSpy.mockRestore();
  });

  it("should return 404 for unknown routes", async () => {
    const response = await request(app).get("/unknown-route");
    expect(response.status).toBe(404);
  });
});
