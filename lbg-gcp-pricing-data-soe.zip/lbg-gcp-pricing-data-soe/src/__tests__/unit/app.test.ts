import request from "supertest";
import app from "../../app.js";

describe("App", () => {
  it("should return Hello World on GET /", async () => {
    const response = await request(app).get("/");
    expect(response.status).toBe(200);
    expect(response.text).toBe("Hello World!--------------------------->");
  });

  it("should return 404 for unknown routes", async () => {
    const response = await request(app).get("/unknown-route");
    expect(response.status).toBe(404);
  });
});
