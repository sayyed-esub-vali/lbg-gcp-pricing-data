import dotenv from 'dotenv';
dotenv.config({ path: '.env.test' });

// jest.mock('../src/config/db', () => ({
//   connectDB: jest.fn().mockResolvedValue(true),
// }));

// Additional global setup can be added here
beforeAll(async () => {
  // Example: Initialize a mock database connection
  // await initializeMockDatabase();
});

afterAll(async () => {
  // Example: Close the mock database connection
  // await closeMockDatabase();
});