import express from "express";
import swaggerUi from "swagger-ui-express";
import swaggerJSDoc from "swagger-jsdoc";

import { getPrices, getByEmail } from "../controllers/priceController.js";

const router = express.Router();

router.get("/", (req, res) => {
  res.send("Hello World!--------------------------- from price route>");
});



router.get("/all-loan-details", getPrices);

router.get("/loan-details-by-email", getByEmail);

export default router;
