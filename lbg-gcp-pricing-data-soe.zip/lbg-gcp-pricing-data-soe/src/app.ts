import express from "express";
import { Request, Response } from "express-serve-static-core";
import fs from "fs";
import path from "path";
import pkg from "pg";
const { Pool } = pkg;
import dotenv from "dotenv";
import priceRouter from "./routes/priceRoutes.js";
import swaggerUi from "swagger-ui-express";
import swaggerJSDoc from "swagger-jsdoc";

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

dotenv.config();
const app = express();
const port = 3000;

app.get("/", (req, res) => {
  res.send("Hello World!--------------------------->");
});

app.use("/api/", priceRouter);

export default app;
